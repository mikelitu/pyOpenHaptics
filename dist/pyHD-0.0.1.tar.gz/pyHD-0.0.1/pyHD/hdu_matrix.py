from ctypes import *

hduMatrix = (c_double * 4) * 4
hduVector3Dd = (c_double * 3)