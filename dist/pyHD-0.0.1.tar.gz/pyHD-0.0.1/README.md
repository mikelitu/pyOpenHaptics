# pyTouch

Python wrapper for the OpenHaptics HD library to use the haptic device directly from Python. 

## Developing...